import math
from datetime import date, datetime, timedelta

from django.db import transaction
from django.db.models import Q
from django.utils import timezone

from app.employees.models import Employee

from common.s3_utils import upload_to_s3

from .models import (
    AttendanceSettings,
    Shift,
    EmployeeShiftAssignment,
    AttendanceRecord,
    AttendancePunch,
    AttendanceCorrection,
)

from .face_recognition_service import (
    FaceVerificationError,
    verify_employee_face,
)

# =========================================================
# SETTINGS
# =========================================================

def get_attendance_settings(organization):
    settings_obj, _ = AttendanceSettings.objects.get_or_create(
        organization=organization
    )
    return settings_obj


# =========================================================
# EMPLOYEE
# =========================================================

def get_employee_for_user(user, organization):
    return Employee.objects.filter(
        user=user,
        organization=organization,
        is_active=True,
        employment_status="ACTIVE",
    ).first()


def get_employee_for_organization(employee_id, organization):
    return Employee.objects.filter(
        id=employee_id,
        organization=organization,
        is_active=True,
        employment_status="ACTIVE",
    ).first()


# =========================================================
# LOCATION VERIFICATION
# =========================================================

def calculate_distance_meters(lat1, lon1, lat2, lon2):
    earth_radius = 6371000

    lat1 = math.radians(float(lat1))
    lon1 = math.radians(float(lon1))
    lat2 = math.radians(float(lat2))
    lon2 = math.radians(float(lon2))

    dlat = lat2 - lat1
    dlon = lon2 - lon1

    a = (
        math.sin(dlat / 2) ** 2
        + math.cos(lat1)
        * math.cos(lat2)
        * math.sin(dlon / 2) ** 2
    )

    c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))
    return earth_radius * c


def verify_office_location(
    organization,
    latitude,
    longitude,
    gps_accuracy_meters,
    attendance_settings,
):
    if not attendance_settings.location_required:
        return {
            "verified": True,
            "distance_meters": None,
            "message": "Location verification is disabled.",
        }

    if latitude is None or longitude is None:
        return {
            "verified": False,
            "distance_meters": None,
            "message": "GPS coordinates are required.",
        }

    if (
        organization.latitude is None
        or organization.longitude is None
    ):
        return {
            "verified": False,
            "distance_meters": None,
            "message": "Company office coordinates are not configured.",
        }

    # Validate GPS accuracy only when provided.
    if gps_accuracy_meters is not None:
        if (
            gps_accuracy_meters
            > attendance_settings.max_gps_accuracy_meters
        ):
            return {
                "verified": False,
                "distance_meters": None,
                "message": "GPS accuracy is insufficient.",
            }

    distance = calculate_distance_meters(
        organization.latitude,
        organization.longitude,
        latitude,
        longitude,
    )

    allowed_radius = attendance_settings.allowed_radius_meters

    return {
        "verified": distance <= allowed_radius,
        "distance_meters": round(distance, 2),
        "message": (
            "Location verified."
            if distance <= allowed_radius
            else "You are outside the permitted attendance location."
        ),
    }


# =========================================================
# SHIFT AND SCHEDULE
# =========================================================

def get_employee_shift(employee, organization, work_date):
    assignment = (
        EmployeeShiftAssignment.objects.filter(
            organization=organization,
            employee=employee,
            shift__organization=organization,
            shift__is_active=True,
            effective_from__lte=work_date,
        )
        .filter(
            models_q_effective_to(work_date)
        )
        .select_related("shift")
        .order_by("-effective_from")
        .first()
    )

    return assignment.shift if assignment else None


def models_q_effective_to(work_date):
    from django.db.models import Q

    return Q(effective_to__isnull=True) | Q(
        effective_to__gte=work_date
    )


# def get_shift_datetimes(shift, work_date, attendance_settings):
#     if shift:
#         start_time = shift.start_time
#         end_time = shift.end_time
#     else:
#         start_time = attendance_settings.default_start_time
#         end_time = attendance_settings.default_end_time

#     scheduled_start = timezone.make_aware(
#         datetime.combine(work_date, start_time),
#         timezone.get_current_timezone(),
#     )

#     crosses_midnight = (
#         shift.crosses_midnight
#         if shift
#         else end_time < start_time
#     )

#     end_date = (
#         work_date + timedelta(days=1)
#         if crosses_midnight or end_time < start_time
#         else work_date
#     )

#     scheduled_end = timezone.make_aware(
#         datetime.combine(end_date, end_time),
#         timezone.get_current_timezone(),
#     )

#     return scheduled_start, scheduled_end


from zoneinfo import ZoneInfo
from django.conf import settings

def get_shift_datetimes(shift, work_date, attendance_settings):
    if shift:
        start_time = shift.start_time
        end_time = shift.end_time
    else:
        start_time = attendance_settings.default_start_time
        end_time = attendance_settings.default_end_time

    # 1. Get the local timezone (Asia/Kolkata)
    tz = ZoneInfo(settings.TIME_ZONE)

    # 2. Combine Date and Time
    naive_start = datetime.combine(work_date, start_time)
    naive_end = datetime.combine(work_date, end_time)

    # 3. Explicitly make them aware in Asia/Kolkata
    scheduled_start = naive_start.replace(tzinfo=tz)

    crosses_midnight = (
        shift.crosses_midnight
        if shift
        else end_time < start_time
    )

    end_date = (
        work_date + timedelta(days=1)
        if crosses_midnight or end_time < start_time
        else work_date
    )

    naive_scheduled_end = datetime.combine(end_date, end_time)
    scheduled_end = naive_scheduled_end.replace(tzinfo=tz)

    return scheduled_start, scheduled_end


# =========================================================
# CREATE ATTENDANCE RECORD
# =========================================================

def get_or_create_attendance(employee, organization, work_date):
    attendance_settings = get_attendance_settings(organization)

    shift = get_employee_shift(
        employee,
        organization,
        work_date,
    )

    scheduled_start, scheduled_end = get_shift_datetimes(
        shift,
        work_date,
        attendance_settings,
    )

    if shift:
        late_grace_minutes = (
            shift.late_grace_minutes
            if shift.late_grace_minutes is not None
            else attendance_settings.late_grace_minutes
        )

        early_departure_grace_minutes = (
            shift.early_departure_grace_minutes
            if shift.early_departure_grace_minutes is not None
            else attendance_settings.early_departure_grace_minutes
        )
    else:
        late_grace_minutes = attendance_settings.late_grace_minutes
        early_departure_grace_minutes = (
            attendance_settings.early_departure_grace_minutes
        )

    attendance, created = AttendanceRecord.objects.get_or_create(
        organization=organization,
        employee=employee,
        work_date=work_date,
        defaults={
            "shift": shift,
            "scheduled_start": scheduled_start,
            "scheduled_end": scheduled_end,
            "late_grace_minutes": late_grace_minutes,
            "early_departure_grace_minutes": early_departure_grace_minutes,
            "status": "INCOMPLETE",
        },
    )

    return attendance


# =========================================================
# CALCULATE ATTENDANCE
# =========================================================


def calculate_attendance(attendance):
    """Update simple attendance facts after a check-in/out or correction.

    - No break deductions.
    - Late/early minutes exclude configured grace periods.
    - Overtime is time after scheduled_end, and is recorded only after checkout.
    - An unfinished or overdue record never gets a fabricated checkout.
    """
    now = timezone.now()
    attendance_settings = get_attendance_settings(attendance.organization)

    if not attendance.check_in:
        attendance.net_work_minutes = 0
        attendance.late_minutes = 0
        attendance.early_departure_minutes = 0
        attendance.overtime_minutes = 0
        attendance.status = "INCOMPLETE"
        attendance.save()
        return attendance

    # Keep overdue attendance pending until a correction supplies the real checkout.
    if attendance.status == "PENDING_REVIEW" and not attendance.check_out:
        attendance.net_work_minutes = 0
        attendance.late_minutes = 0
        attendance.early_departure_minutes = 0
        attendance.overtime_minutes = 0
        attendance.save()
        return attendance

    end_time = attendance.check_out or now
    if end_time < attendance.check_in:
        attendance.status = "PENDING_REVIEW"
        attendance.net_work_minutes = 0
        attendance.overtime_minutes = 0
        attendance.save()
        return attendance

    # Actual elapsed time, without break deductions. For incomplete records this
    # value is temporary; overtime and final status wait for checkout.
    attendance.net_work_minutes = int(
        (end_time - attendance.check_in).total_seconds() // 60
    )

    attendance.late_minutes = 0
    if attendance.scheduled_start:
        late_by = int(
            (attendance.check_in - attendance.scheduled_start).total_seconds() // 60
        )
        attendance.late_minutes = max(0, late_by - attendance.late_grace_minutes)

    attendance.early_departure_minutes = 0
    if attendance.check_out and attendance.scheduled_end:
        early_by = int(
            (attendance.scheduled_end - attendance.check_out).total_seconds() // 60
        )
        attendance.early_departure_minutes = max(
            0, early_by - attendance.early_departure_grace_minutes
        )

    # Calculate overtime only after the actual checkout is available.
    attendance.overtime_minutes = 0
    if attendance.check_out and attendance.scheduled_end:
        extra_minutes = max(
            0,
            int((attendance.check_out - attendance.scheduled_end).total_seconds() // 60),
        )
        minimum_overtime = attendance_settings.overtime_minimum_minutes
        if extra_minutes >= minimum_overtime:
            if attendance_settings.overtime_include_threshold:
                attendance.overtime_minutes = extra_minutes
            else:
                attendance.overtime_minutes = (
                    extra_minutes - minimum_overtime
                )

    if not attendance.check_out:
        if attendance.status != "PENDING_REVIEW":
            attendance.status = "INCOMPLETE"
    elif (
        attendance.net_work_minutes < attendance_settings.half_day_threshold_minutes
        or attendance.late_minutes >= attendance_settings.late_half_day_threshold_minutes
        or attendance.early_departure_minutes
        >= attendance_settings.early_departure_half_day_threshold_minutes
    ):
        attendance.status = "HALF_DAY"
    else:
        attendance.status = "PRESENT"

    attendance.save()
    return attendance


# =========================================================
# PROCESS CHECK-IN / CHECK-OUT
# =========================================================



def get_attendance_work_date(employee, organization, now):
    """
    Attribute an after-midnight check-in to yesterday when
    yesterday's assigned overnight shift is still in progress.
    """
    current_date = timezone.localtime(now).date()
    previous_date = current_date - timedelta(days=1)

    attendance_settings = get_attendance_settings(organization)

    previous_shift = get_employee_shift(
        employee,
        organization,
        previous_date,
    )

    if not previous_shift or not previous_shift.crosses_midnight:
        return current_date

    scheduled_start, scheduled_end = get_shift_datetimes(
        previous_shift,
        previous_date,
        attendance_settings,
    )

    if not (scheduled_start <= now < scheduled_end):
        return current_date

    previous_attendance = AttendanceRecord.objects.filter(
        organization=organization,
        employee=employee,
        work_date=previous_date,
    ).first()

    # Do not create a second attendance record for the same shift date.
    if previous_attendance and previous_attendance.check_in:
        return current_date

    return previous_date



@transaction.atomic
def process_attendance_punch(
    employee,
    organization,
    latitude=None,
    longitude=None,
    gps_accuracy_meters=None,
    selfie_file=None,
    recorded_by=None,
):
    now = timezone.now()
    current_date = timezone.localdate(now)

    attendance_settings = get_attendance_settings(organization)

    face_result = {"verified": False, "similarity": None, "threshold": None}
    if attendance_settings.photo_required and not selfie_file:
        raise ValueError("A selfie is required for face verification.")

    if selfie_file:
        try:
            face_result = verify_employee_face(
                employee=employee,
                selfie_file=selfie_file,
            )
        except FaceVerificationError as exc:
            raise ValueError(str(exc)) from exc

        if not face_result["verified"]:
            raise ValueError(
                "Face does not match your registered profile photo."
            )

    location_result = verify_office_location(
        organization=organization,
        latitude=latitude,
        longitude=longitude,
        gps_accuracy_meters=gps_accuracy_meters,
        attendance_settings=attendance_settings,
    )

    if not location_result["verified"]:
        raise ValueError(location_result["message"])

    # Find the latest unfinished attendance, including overdue sessions.
    open_attendance = (
        AttendanceRecord.objects.select_for_update()
        .filter(
            organization=organization,
            employee=employee,
            check_in__isnull=False,
            check_out__isnull=True,
            status="INCOMPLETE",
        )
        .order_by("-check_in")
        .first()
    )

    attendance = None
    punch_type = "CHECK_IN"

    if open_attendance:
        deadline = (
            open_attendance.scheduled_end + timedelta(hours=4)
            if open_attendance.scheduled_end
            else open_attendance.check_in + timedelta(hours=18)
        )

        is_same_work_date = open_attendance.work_date == current_date
        is_overnight_checkout_window = bool(
            open_attendance.shift
            and open_attendance.shift.crosses_midnight
            and now <= deadline
        )

        # Same-day punches may check out after shift end. An overnight shift may
        # also check out on the next calendar day, up to four hours after its
        # scheduled end. A regular previous-day record never consumes today's punch.
        if now <= deadline and (is_same_work_date or is_overnight_checkout_window):
            attendance = open_attendance
            punch_type = "CHECK_OUT"

        else:
            # A same-date second punch cannot create a second attendance row.
            # Raise before changing anything so the atomic transaction is clean.
            if open_attendance.work_date == current_date:
                raise ValueError(
                    "Your attendance is still open for today. Use the correction "
                    "API if you forgot to check out."
                )

            # Previous work date: flag it for correction, then allow today's check-in.
            # Never fabricate a checkout time or keep accumulating overtime.
            open_attendance.status = "PENDING_REVIEW"
            open_attendance.net_work_minutes = 0
            open_attendance.overtime_minutes = 0
            open_attendance.updated_by = recorded_by
            open_attendance.save(
                update_fields=[
                    "status", "net_work_minutes", "overtime_minutes",
                    "updated_by", "updated_at",
                ]
            )

    # If there is no active checkout, determine the correct shift date.
    if punch_type == "CHECK_IN":
        work_date = get_attendance_work_date(
            employee,
            organization,
            now,
        )

        attendance = get_or_create_attendance(
            employee,
            organization,
            work_date,
        )

        if attendance.check_in:
            raise ValueError(
                "Attendance already exists for this work date. "
                "Use the attendance correction request if it is incorrect."
            )

        if attendance.scheduled_end and now >= attendance.scheduled_end:
            raise ValueError(
                "This shift has already ended. Contact your manager "
                "if you need an attendance correction."
            )

    elif attendance.check_out:
        raise ValueError("You have already checked out.")

    # Upload the selfie only after verification and timing checks.
    selfie_path = (
        upload_to_s3(file=selfie_file, folder="attendance/selfies")
        if selfie_file
        else None
    )

    punch = AttendancePunch(
        attendance=attendance,
        punch_type=punch_type,
        punched_at=now,
        latitude=latitude,
        longitude=longitude,
        gps_accuracy_meters=gps_accuracy_meters,
        office_distance_meters=location_result["distance_meters"],
        location_verified=location_result["verified"],
        face_verified=bool(face_result["verified"]),
        face_similarity=face_result["similarity"],
        verification_status="VERIFIED",
        verification_details={
            "location_message": location_result["message"],
            "photo_provided": bool(selfie_file),
            "face_verification": (
                "Verified" if face_result["verified"] else "Skipped"
            ),
            "face_model": "OpenCV SFace" if face_result["verified"] else None,
            "face_similarity": face_result["similarity"],
            "face_threshold": face_result["threshold"],
        },
        recorded_by=recorded_by,
        is_manual=False,
    )

    if selfie_path:
        punch.selfie.name = selfie_path
    punch.save()

    if punch_type == "CHECK_IN":
        attendance.check_in = now
        attendance.created_by = recorded_by
    else:
        attendance.check_out = now

    attendance.updated_by = recorded_by
    attendance.save()

    calculate_attendance(attendance)

    return attendance, punch


# =========================================================
# ATTENDANCE CORRECTION
# =========================================================

@transaction.atomic
def create_attendance_correction(
    attendance,
    field_name,
    new_value,
    reason,
    requested_by,
    punch=None,
):
    allowed_fields = {
        "CHECK_IN",
        "CHECK_OUT",
        "STATUS",
    }

    if field_name not in allowed_fields:
        raise ValueError("Invalid attendance correction field.")

    if punch and punch.attendance_id != attendance.id:
        raise ValueError(
            "The selected punch does not belong to this attendance record."
        )

    field_mapping = {
        "CHECK_IN": "check_in",
        "CHECK_OUT": "check_out",
        "STATUS": "status",
    }

    model_field = field_mapping[field_name]
    old_value = getattr(attendance, model_field)

    if isinstance(old_value, datetime):
        old_value = old_value.isoformat()

    correction = AttendanceCorrection.objects.create(
        attendance=attendance,
        punch=punch,
        field_name=field_name,
        old_value=old_value,
        new_value=new_value,
        reason=reason,
        requested_by=requested_by,
        status="PENDING",
    )

    return correction



@transaction.atomic
def review_attendance_correction(
    correction,
    reviewed_by,
    approve,
    review_note="",
):
    if correction.status != "PENDING":
        raise ValueError("This correction has already been reviewed.")

    correction.reviewed_by = reviewed_by
    correction.reviewed_at = timezone.now()
    correction.review_note = review_note

    if not approve:
        correction.status = "REJECTED"
        correction.save()
        return correction

    attendance = correction.attendance

    field_mapping = {
        "CHECK_IN": "check_in",
        "CHECK_OUT": "check_out",
        "STATUS": "status",
    }

    field_name = correction.field_name

    if field_name not in field_mapping:
        raise ValueError("Invalid correction field.")

    model_field = field_mapping[field_name]
    value = correction.new_value

    if field_name in {"CHECK_IN", "CHECK_OUT"}:
        try:
            value = datetime.fromisoformat(str(value))
        except (TypeError, ValueError) as exc:
            raise ValueError(
                "The corrected time must be a valid ISO 8601 datetime."
            ) from exc

        if timezone.is_naive(value):
            value = timezone.make_aware(
                value,
                timezone.get_current_timezone(),
            )

        # Validate against the other attendance timestamp.
        if field_name == "CHECK_OUT":
            effective_check_in = attendance.check_in

            if effective_check_in and value < effective_check_in:
                raise ValueError(
                    "Check-out cannot be earlier than check-in."
                )

        elif field_name == "CHECK_IN":
            effective_check_out = attendance.check_out

            if effective_check_out and value > effective_check_out:
                raise ValueError(
                    "Check-in cannot be later than check-out."
                )

    elif field_name == "STATUS":
        valid_statuses = {
            choice[0] for choice in AttendanceRecord.STATUS_CHOICES
        }

        if value not in valid_statuses:
            raise ValueError("Invalid attendance status.")

    setattr(attendance, model_field, value)
    attendance.updated_by = reviewed_by

    # If check-in is corrected while a pending-review record still has no
    # checkout, return it to INCOMPLETE so its attendance facts are recalculated.
    if (
        field_name == "CHECK_IN"
        and attendance.check_out is None
        and attendance.status == "PENDING_REVIEW"
    ):
        attendance.status = "INCOMPLETE"

    attendance.save()

    # Recalculate after a time correction, including an overdue session.
    if field_name in {"CHECK_IN", "CHECK_OUT"}:
        calculate_attendance(attendance)

    correction.status = "APPLIED"
    correction.save()

    return correction


# =========================================================
# MARK ABSENT
# Call from a scheduled task after the shift's start/grace period.
# =========================================================

@transaction.atomic
def mark_employee_absent(employee, organization, work_date):
    attendance = get_or_create_attendance(
        employee,
        organization,
        work_date,
    )

    if attendance.check_in:
        return attendance

    if attendance.status in {"ON_LEAVE", "WEEKLY_OFF", "HOLIDAY"}:
        return attendance

    attendance.status = "ABSENT"
    attendance.save(
        update_fields=[
            "status",
            "updated_at",
        ]
    )

    return attendance



# =========================================================
# SHIFT ASSIGNMENT HELPERS
# =========================================================

def validate_shift_assignment_range(
    organization,
    employee,
    shift,
    effective_from,
    effective_to,
    exclude_assignment_id=None,
):
    """Reject overlapping assignments for the same employee."""

    if employee.organization_id != organization.id:
        raise ValueError(
            f"Employee {employee.id} does not belong to this organization."
        )

    if not employee.is_active or employee.employment_status != "ACTIVE":
        raise ValueError(
            f"Employee {employee.id} is not active."
        )

    if shift.organization_id != organization.id:
        raise ValueError(
            f"Shift {shift.id} does not belong to this organization."
        )

    if not shift.is_active:
        raise ValueError(f"Shift '{shift.name}' is inactive.")

    if effective_to and effective_to < effective_from:
        raise ValueError("End date cannot be before start date.")

    conflicts = EmployeeShiftAssignment.objects.filter(
        organization=organization,
        employee=employee,
        effective_from__lte=effective_to or date.max,
    ).filter(
        Q(effective_to__isnull=True)
        | Q(effective_to__gte=effective_from)
    )

    if exclude_assignment_id is not None:
        conflicts = conflicts.exclude(pk=exclude_assignment_id)

    conflict = conflicts.select_related("shift").first()

    if conflict:
        raise ValueError(
            f"Employee {employee.id} already has shift "
            f"'{conflict.shift.name}' assigned from "
            f"{conflict.effective_from} to "
            f"{conflict.effective_to or 'open-ended'}."
        )


def validate_common_weekly_offs(
    organization,
    shifts,
    date_from,
    date_to,
):
    """
    Rotation shifts must have the same weekly-off behavior
    throughout the requested date range.
    Organization-wide holidays apply equally to all shifts.
    """

    from app.calendar_app.services import get_calendar_day

    if len(shifts) <= 1:
        return

    current_date = date_from

    while current_date <= date_to:
        day_results = [
            get_calendar_day(
                organization=organization,
                target_date=current_date,
                shift=shift,
            )
            for shift in shifts
        ]

        # Holidays are organization-wide, so they do not create
        # a difference between the shifts' weekly-off schedules.
        if all(
            result["day_type"] == "HOLIDAY"
            for result in day_results
        ):
            current_date += timedelta(days=1)
            continue

        weekly_off_statuses = [
            result["day_type"] == "WEEKLY_OFF"
            for result in day_results
        ]

        if len(set(weekly_off_statuses)) > 1:
            raise ValueError(
                "Rotation shifts must share the same weekly-off "
                f"schedule. The schedules differ on {current_date}."
            )

        current_date += timedelta(days=1)


# =========================================================
# BULK ASSIGN ONE SHIFT TO MULTIPLE EMPLOYEES
# =========================================================

@transaction.atomic
def bulk_assign_shift(
    organization,
    employee_ids,
    shift_id,
    effective_from,
    effective_to=None,
    assigned_by=None,
):
    employees = list(
        Employee.objects.select_for_update().filter(
            id__in=employee_ids,
            organization=organization,
        ).order_by("id")
    )

    if len(employees) != len(set(employee_ids)):
        raise ValueError(
            "One or more employees do not belong to this organization "
            "or do not exist."
        )

    shift = Shift.objects.filter(
        id=shift_id,
        organization=organization,
        is_active=True,
    ).first()

    if not shift:
        raise ValueError("Active shift not found in this organization.")

    # Validate everyone before creating any assignment.
    for employee in employees:
        validate_shift_assignment_range(
            organization=organization,
            employee=employee,
            shift=shift,
            effective_from=effective_from,
            effective_to=effective_to,
        )

    assignments = [
        EmployeeShiftAssignment(
            organization=organization,
            employee=employee,
            shift=shift,
            effective_from=effective_from,
            effective_to=effective_to,
            assigned_by=assigned_by,
        )
        for employee in employees
    ]

    return EmployeeShiftAssignment.objects.bulk_create(assignments)


# =========================================================
# BULK ASSIGN A ROTATING SHIFT PATTERN
# =========================================================

@transaction.atomic
def bulk_assign_shift_pattern(
    organization,
    employee_ids,
    start_date,
    pattern,
    repetitions=1,
    assigned_by=None,
    auto_close_prior=False,
):
    """
    Example pattern:
    [
        {"shift_id": 1, "duration_days": 7},
        {"shift_id": 2, "duration_days": 7},
    ]

    Each duration is inclusive. A 7-day block occupies seven
    calendar dates, and the next block starts the following day.
    """

    if not employee_ids:
        raise ValueError("Select at least one employee.")

    if not pattern:
        raise ValueError("Provide at least one shift pattern block.")

    if repetitions < 1:
        raise ValueError("Repetitions must be at least 1.")

    # CHANGED: reject duplicate employee IDs up front.
    if len(employee_ids) != len(set(employee_ids)):
        raise ValueError("employee_ids contains duplicate IDs.")

    # Validate pattern and collect its shifts.
    shift_ids = []
    total_days = 0

    for block in pattern:
        shift_id = block.get("shift_id")
        duration_days = block.get("duration_days")

        if not shift_id:
            raise ValueError("Every pattern block needs a shift_id.")

        # CHANGED: reject booleans (JSON true/false) as durations.
        if (
            isinstance(duration_days, bool)
            or not isinstance(duration_days, int)
            or duration_days < 1
        ):
            raise ValueError(
                "duration_days must be a positive integer."
            )

        shift_ids.append(shift_id)
        total_days += duration_days

    shifts = {
        shift.id: shift
        for shift in Shift.objects.filter(
            organization=organization,
            id__in=set(shift_ids),
            is_active=True,
        )
    }

    if len(shifts) != len(set(shift_ids)):
        raise ValueError(
            "One or more shifts are missing, inactive, or belong "
            "to another organization."
        )

    # CHANGED: added select_for_update() to lock employee rows
    employees = list(
        Employee.objects.select_for_update().filter(
            id__in=employee_ids,
            organization=organization,
        ).order_by("id")
    )

    if len(employees) != len(set(employee_ids)):
        raise ValueError(
            "One or more employees do not belong to this organization "
            "or do not exist."
        )

    # Generate all date blocks first. No database writes yet.
    blocks = []
    current_date = start_date

    for _ in range(repetitions):
        for item in pattern:
            block_start = current_date
            block_end = (
                block_start
                + timedelta(days=item["duration_days"] - 1)
            )

            blocks.append({
                "shift": shifts[item["shift_id"]],
                "effective_from": block_start,
                "effective_to": block_end,
            })

            current_date = block_end + timedelta(days=1)

    final_date = blocks[-1]["effective_to"]

    # Validate weekly-off behavior before creating assignments.
    validate_common_weekly_offs(
        organization=organization,
        shifts=list(shifts.values()),
        date_from=start_date,
        date_to=final_date,
    )

    # CHANGED: validate every employee fully BEFORE modifying any prior
    # assignment. prior assignments are locked and cached here, then closed
    # only after all checks pass.
    prior_assignments_by_employee = {}
    for employee in employees:
        prior_open_assignments = list(
            EmployeeShiftAssignment.objects.select_for_update().filter(
                organization=organization,
                employee=employee,
                effective_from__lt=start_date,
                effective_to__isnull=True,
            ).select_related("shift")
        )

        prior_assignments_by_employee[employee.id] = (
            prior_open_assignments
        )

        if prior_open_assignments and not auto_close_prior:
            raise ValueError(
                f"Employee {employee.id} has an existing "
                "open-ended shift assignment. Set auto_close_prior "
                "to true to close it before the new pattern."
            )

        # Validate that prior assignments can safely be closed.
        for prior in prior_open_assignments:
            has_conflicting_attendance = (
                AttendanceRecord.objects.filter(
                    organization=organization,
                    employee=employee,
                    shift=prior.shift,
                    work_date__gte=start_date,
                ).exists()
            )

            if has_conflicting_attendance:
                raise ValueError(
                    f"Cannot close the previous assignment for "
                    f"employee {employee.id}: attendance records "
                    f"already exist on or after {start_date} for "
                    f"shift '{prior.shift.name}'."
                )

        # Reject any other assignment overlapping the requested period.
        overlapping = EmployeeShiftAssignment.objects.filter(
            organization=organization,
            employee=employee,
            effective_from__lte=final_date,
        ).filter(
            Q(effective_to__isnull=True)
            | Q(effective_to__gte=start_date)
        )

        # CHANGED: exclude the open-ended assignments we intend to close
        # (auto_close_prior) so genuine conflicts are still detected.
        prior_ids = [assignment.id for assignment in prior_open_assignments]
        if prior_ids:
            overlapping = overlapping.exclude(id__in=prior_ids)

        conflict = overlapping.select_related("shift").first()

        if conflict:
            raise ValueError(
                f"Employee {employee.id} already has an assignment "
                f"for shift '{conflict.shift.name}' overlapping "
                f"{start_date} to {final_date}."
            )

    # CHANGED: all validations passed — now safely close prior open-ended
    # assignments that were validated above.
    for employee in employees:
        for prior in prior_assignments_by_employee[employee.id]:
            prior.effective_to = start_date - timedelta(days=1)
            prior.save(update_fields=["effective_to", "updated_at"])

    # All checks passed. Create every block for every employee.
    assignments = []

    for employee in employees:
        for block in blocks:
            assignments.append(
                EmployeeShiftAssignment(
                    organization=organization,
                    employee=employee,
                    shift=block["shift"],
                    effective_from=block["effective_from"],
                    effective_to=block["effective_to"],
                    assigned_by=assigned_by,
                )
            )

    return EmployeeShiftAssignment.objects.bulk_create(assignments)


# =========================================================
# BULK MARK ABSENT
# Creates ABSENT AttendanceRecord rows for every eligible employee
# who has no record on a working day in the given range.
# =========================================================

@transaction.atomic
def bulk_mark_absent(
    organization,
    from_date,
    to_date,
    employee_ids=None,
    marked_by=None,
):
    """
    Create ABSENT records for every eligible employee who has no
    AttendanceRecord on a working day in [from_date, to_date].

    Rules:
      - Only runs when AttendanceSettings.auto_mark_absent is True.
      - Only active employees with employment_status in
        (ACTIVE, ON_LEAVE) belonging to `organization`.
      - Skips non-working days (HOLIDAY / WEEKLY_OFF / NO_SHIFT_ASSIGNED).
      - Skips days where an AttendanceRecord already exists.
      - Never overwrites an existing record.
      - Date range capped at MAX_DAYS (safety net).
    """
    from app.calendar_app.services import get_calendar_day
    from app.employees.models import Employee

    MAX_DAYS = 62  # safety net — change to your required number

    if from_date > to_date:
        raise ValueError("from_date cannot be after to_date.")

    if (to_date - from_date).days > MAX_DAYS:
        raise ValueError(
            f"Date range cannot exceed {MAX_DAYS} days."
        )

    attendance_settings = get_attendance_settings(organization)

    if not attendance_settings.auto_mark_absent:
        raise ValueError(
            "Auto-mark-absent is disabled for this organization."
        )

    employees_qs = Employee.objects.filter(
        organization=organization,
        is_active=True,
        employment_status__in=["ACTIVE", "ON_LEAVE"],
    ).order_by("id")

    if employee_ids:
        employees_qs = employees_qs.filter(id__in=employee_ids)
        employees = list(employees_qs)
        matched_ids = {e.id for e in employees}
        missing_ids = sorted(set(employee_ids) - matched_ids)
        if missing_ids:
            raise ValueError(
                f"These employee IDs are not active or do not belong to "
                f"this organization: {missing_ids}."
            )
    else:
        employees = list(employees_qs)

    if not employees:
        return {
            "created_count": 0,
            "skipped_existing": 0,
            "skipped_non_working": 0,
            "employees_processed": 0,
            "from_date": str(from_date),
            "to_date": str(to_date),
        }

    employee_ids_set = [e.id for e in employees]

    existing_pairs = set(
        AttendanceRecord.objects.filter(
            organization=organization,
            employee_id__in=employee_ids_set,
            work_date__range=(from_date, to_date),
        ).values_list("employee_id", "work_date")
    )

    created_count = 0
    skipped_existing = 0
    skipped_non_working = 0

    current_date = from_date
    while current_date <= to_date:
        for employee in employees:
            if (employee.id, current_date) in existing_pairs:
                skipped_existing += 1
                continue

            shift = get_employee_shift(employee, organization, current_date)

            calendar_day = get_calendar_day(
                organization=organization,
                target_date=current_date,
                shift=shift,
            )

            if not calendar_day.get("is_working_day"):
                skipped_non_working += 1
                continue

            attendance = get_or_create_attendance(
                employee, organization, current_date,
            )

            if attendance.check_in or attendance.status in {
                "PRESENT", "HALF_DAY", "ON_LEAVE",
            }:
                skipped_existing += 1
                continue

            attendance.status = "ABSENT"
            attendance.created_by = marked_by
            attendance.updated_by = marked_by
            attendance.save(
                update_fields=[
                    "status", "created_by", "updated_by", "updated_at",
                ]
            )
            created_count += 1

        current_date += timedelta(days=1)

    return {
        "created_count": created_count,
        "skipped_existing": skipped_existing,
        "skipped_non_working": skipped_non_working,
        "employees_processed": len(employees),
        "from_date": str(from_date),
        "to_date": str(to_date),
    }
